Existen cuatro ficheros de provincias.

data_provincias_dos.xml
Nombres de provincias en dos idiomas para comunidades con dos idiomas oficiales

data_provincias_es.xml
Nombres de provincias únicamente en castellano

data_provincias_aut.xml
Nombres de provincias en idioma autonómico para comunidades con dos idiomas oficiales

data_provincias_mix.xml
Nombres de provincias en castellano o idioma autonómico para comunidades con dos idiomas oficiales
