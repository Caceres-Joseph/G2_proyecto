import lopd
import fichero
import extension_partner
import extension_hr
#import evaluacion
import registros
import figuras_tratamiento
import fichero_nota
import wizard

