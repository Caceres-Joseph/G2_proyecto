import funciones
import fdfgen
import barcode128

